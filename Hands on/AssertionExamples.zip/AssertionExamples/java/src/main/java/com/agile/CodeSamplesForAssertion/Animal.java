package com.agile.CodeSamplesForAssertion;

//This interface is implemented by DerivedClass.java
public interface Animal {
    public void Move();
}